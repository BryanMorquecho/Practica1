package Materia.Pilas;

import java.util.EmptyStackException;

import Materia.Models.NodoGenerico;

public class PilaGenerica<T> {
    private NodoGenerico<T> Top;

    public PilaGenerica(T data){
        Top = null;


    }
    public void push(T data){
        NodoGenerico<T> NuevoNodo= new NodoGenerico<T>(data);
        NuevoNodo.next= Top;
        Top = NuevoNodo;
    }
    public boolean isEmpty(){
        return Top == null;
    }
    public T pop(T data){
        if(isEmpty()){
            System.out.println(" La pila esta vacia ");
            throw new EmptyStackException();

        }
        //T data = Top.data;
        //Top = Top.next;
        return data;
    }

     public T peek(T data){
        if(isEmpty()){
            System.out.println(" La pila esta vacia ");
            throw new EmptyStackException();

        }
       return Top.data;

     }

    
}
