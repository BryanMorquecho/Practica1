package Materia.Pilas;
import java.util.EmptyStackException;

import Materia.Models.Node;

public class Pila {
    private Node Top;

    public Pila(){
        Top = null;
    }

    //PUSH: Agregar elelmento a la Pila
    public void push (int value){
        Node NuevoNode =new Node(value);
        NuevoNode.next = Top;
        Top = NuevoNode;
    } 

    public int pop(){
        if( Top==null){
            System.out.println("La pila esta vacia");
           //return 0;
           throw new EmptyStackException();
        }else{
            int value = Top.value;
            Top= Top.next;
            return value;
        }
    }
    public int peek(){
        if( Top==null){
            System.out.println("La pila esta vacia");
           return 0;
           //throw new EmptyStackException();
        } 
        return Top.value;

    }
    public boolean isEmpty(){
        return Top == null;
    }


    
}
