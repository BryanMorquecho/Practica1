package Materia.Models;

public class Pantalla {
    private String Nombre;
    private String Ruta;
    public Pantalla(String nombre,String ruta){
        this.Nombre = nombre;
        this.Ruta = ruta;
       

    }
    public String getNombre(){
        return Nombre;

    }
    public void setNombre(String nombre){
        this.Nombre= nombre;

    }
    public String getRuta(){
        return Ruta;

    }
    public void setRuta(String ruta){
        this.Ruta = ruta;

    }


    
}
